﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite o primeiro número: ");
        double num1 = double.Parse(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        double num2 = double.Parse(Console.ReadLine());

        // Operações
        double soma = num1 + num2;
        double subtracao = num1 - num2;
        double multiplicacao = num1 * num2;
        double divisao = num2 != 0 ? num1 / num2 : double.NaN;

        // Saída
        Console.WriteLine("\n--- RESULTADOS ---");
        Console.WriteLine($"Adição: {num1} + {num2} = {soma}");
        Console.WriteLine($"Subtração: {num1} - {num2} = {subtracao}");
        Console.WriteLine($"Multiplicação: {num1} * {num2} = {multiplicacao}");

        if (num2 != 0)
            Console.WriteLine($"Divisão: {num1} / {num2} = {divisao}");
        else
            Console.WriteLine("Divisão: Não é possível dividir por zero.");
    }
}
