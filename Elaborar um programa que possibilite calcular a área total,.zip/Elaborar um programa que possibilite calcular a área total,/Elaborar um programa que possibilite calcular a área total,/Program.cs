﻿using System;

class Program
{
    static void Main()
    {
        double largura, comprimento, areaComodo, areaTotal = 0;
        string nomeComodo, continuar;

        do
        {
            // Entrada de dados do cômodo
            Console.Write("\nDigite o nome do cômodo: ");
            nomeComodo = Console.ReadLine();

            Console.Write("Digite a largura do cômodo (em metros): ");
            largura = double.Parse(Console.ReadLine());

            Console.Write("Digite o comprimento do cômodo (em metros): ");
            comprimento = double.Parse(Console.ReadLine());

            // Calcula a área do cômodo
            areaComodo = largura * comprimento;
            areaTotal += areaComodo;

            // Exibe área do cômodo
            Console.WriteLine($"Área do {nomeComodo}: {areaComodo:F2} m²");

            // Pergunta se deseja continuar
            Console.Write("Deseja adicionar outro cômodo? (sim/não): ");
            continuar = Console.ReadLine().ToLower();

        } while (continuar == "sim");

        // Exibe área total
        Console.WriteLine($"\nÁrea total da residência: {areaTotal:F2} m²");
    }
}
