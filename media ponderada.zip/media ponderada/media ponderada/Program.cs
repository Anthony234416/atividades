﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite o primeiro valor: ");
        double valor1 = double.Parse(Console.ReadLine());

        Console.Write("Digite o segundo valor: ");
        double valor2 = double.Parse(Console.ReadLine());

        Console.Write("Digite o terceiro valor: ");
        double valor3 = double.Parse(Console.ReadLine());

        // Pesos
        int peso1 = 3;
        int peso2 = 3;
        int peso3 = 4;

        // Cálculo da média ponderada
        double somaPesos = peso1 + peso2 + peso3;
        double mediaPonderada = (valor1 * peso1 + valor2 * peso2 + valor3 * peso3) / somaPesos;

        // Saída
        Console.WriteLine($"\nMédia ponderada: {mediaPonderada:F2}");
    }
}