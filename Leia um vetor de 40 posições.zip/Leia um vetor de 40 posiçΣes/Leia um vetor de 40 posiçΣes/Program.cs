﻿using System;

class Program
{
    static void Main()
    {
        int[] vetor = new int[40];
        int contadorPares = 0;

        Console.WriteLine("Digite 40 números:");

        // Leitura dos 40 números e contagem dos pares
        for (int i = 0; i < 40; i++)
        {
            Console.Write($"Posição {i + 1}: ");
            vetor[i] = int.Parse(Console.ReadLine());

            if (vetor[i] % 2 == 0)
            {
                contadorPares++;
            }
        }

        // Exibição do resultado
        Console.WriteLine($"\nQuantidade de números pares no vetor: {contadorPares}");
    }
}
