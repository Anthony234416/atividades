﻿using System;

class Program
{
    static void Main()
    {
        double altura, maiorAltura = 0, menorAltura = double.MaxValue;
        double somaAlturasMulheres = 0, somaAlturasTotal = 0;
        int totalMulheres = 0, totalHomens = 0;
        string sexo;

        for (int i = 1; i <= 7; i++)
        {
            Console.WriteLine($"\nPessoa {i}:");

            Console.Write("Digite a altura (em metros): ");
            altura = double.Parse(Console.ReadLine());

            Console.Write("Digite o sexo (m/f): ");
            sexo = Console.ReadLine().ToLower();

            // Atualiza maior e menor altura
            if (altura > maiorAltura)
                maiorAltura = altura;

            if (altura < menorAltura)
                menorAltura = altura;

            // Soma alturas
            somaAlturasTotal += altura;

            // Classifica por sexo
            if (sexo == "f")
            {
                somaAlturasMulheres += altura;
                totalMulheres++;
            }
            else if (sexo == "m")
            {
                totalHomens++;
            }
            else
            {
                Console.WriteLine("Sexo inválido. Digite 'm' ou 'f'.");
                i--; // repete a iteração
            }
        }

        double mediaGeral = somaAlturasTotal / 7;
        double mediaMulheres = totalMulheres > 0 ? somaAlturasMulheres / totalMulheres : 0;

        // Exibição dos resultados
        Console.WriteLine("\n--- RESULTADOS ---");
        Console.WriteLine($"Maior altura: {maiorAltura:F2} m");
        Console.WriteLine($"Menor altura: {menorAltura:F2} m");
        Console.WriteLine($"Média de altura das mulheres: {mediaMulheres:F2} m");
        Console.WriteLine($"Média de altura geral: {mediaGeral:F2} m");
        Console.WriteLine($"Total de homens cadastrados: {totalHomens}");
    }
}
