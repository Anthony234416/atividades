﻿using System;

class Program
{
    static void Main()
    {
        int[] vetor = new int[16];

        // Leitura do vetor
        Console.WriteLine("Digite 16 números:");
        for (int i = 0; i < 16; i++)
        {
            Console.Write($"Posição {i + 1}: ");
            vetor[i] = int.Parse(Console.ReadLine());
        }

        // Troca dos 8 primeiros com os 8 últimos
        for (int i = 0; i < 8; i++)
        {
            int temp = vetor[i];
            vetor[i] = vetor[i + 8];
            vetor[i + 8] = temp;
        }

        // Exibição do vetor final
        Console.WriteLine("\nVetor após a troca:");
        for (int i = 0; i < 16; i++)
        {
            Console.Write(vetor[i] + " ");
        }
        Console.WriteLine();
    }
}
