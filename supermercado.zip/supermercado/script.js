function mostrarPromocao() {
    let produto = document.getElementById('produto').value;
    let preco = Number(document.getElementById('preco').value);
  
    let total = (2 * preco) + (preco / 2);
    let terceiroProduto = preco / 2;
  
    document.getElementById('saida1').innerHTML = `<strong>${produto}</strong> - Promoção: Leve 3 por R$: ${total.toFixed(2)}`;
    document.getElementById('saida2').innerHTML = `O 3º produto custa apenas R$: ${terceiroProduto.toFixed(2)}`;
  }
  