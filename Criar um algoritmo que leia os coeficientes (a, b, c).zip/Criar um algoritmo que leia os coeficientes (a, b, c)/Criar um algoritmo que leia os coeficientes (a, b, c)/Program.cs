﻿using System;

class Program
{
    static void Main()
    {
        // Entrada dos coeficientes
        Console.Write("Digite o valor de a: ");
        double a = double.Parse(Console.ReadLine());

        Console.Write("Digite o valor de b: ");
        double b = double.Parse(Console.ReadLine());

        Console.Write("Digite o valor de c: ");
        double c = double.Parse(Console.ReadLine());

        // Verificação se é equação do 2º grau
        if (a == 0)
        {
            Console.WriteLine("\nIsso não é uma equação do 2º grau (a não pode ser zero).");
            return;
        }

        // Cálculo do delta
        double delta = Math.Pow(b, 2) - 4 * a * c;

        // Verificação da quantidade de raízes reais
        Console.WriteLine($"\nValor de delta: {delta}");

        if (delta < 0)
        {
            Console.WriteLine("A equação não possui raízes reais.");
        }
        else if (delta == 0)
        {
            Console.WriteLine("A equação possui uma única raiz real.");
        }
        else
        {
            Console.WriteLine("A equação possui duas raízes reais.");
        }
    }
}
