﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite a temperatura em graus Fahrenheit: ");
        double fahrenheit = double.Parse(Console.ReadLine());

        // Conversão para Celsius
        double celsius = (5.0 / 9.0) * (fahrenheit - 32);

        // Saída
        Console.WriteLine($"\nTemperatura em Celsius: {celsius:F2} °C");
    }
}
