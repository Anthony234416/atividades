﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite um valor: ");
        double valor = double.Parse(Console.ReadLine());

        // Verificação se é positivo
        if (valor > 0)
        {
            Console.WriteLine("O valor é positivo.");
        }
        else
        {
            Console.WriteLine("O valor não é positivo.");
        }
    }
}
