function calcular() {
    const valorHora = parseFloat(document.getElementById("valorHora").value);
    if (valorHora === 0) {
        document.getElementById("resultado").innerText = "Sistema encerrado.";
        return;
    }

    const qtdHoras = parseFloat(document.getElementById("qtdHoras").value);
    const valeTransporte = document.getElementById("valeTransporte").value.toUpperCase();
    const outrasDeducoes = parseFloat(document.getElementById("outrasDeducoes").value);

    const salarioBruto = valorHora * qtdHoras;

    // INSS
    let inss = 0;
    let restante = salarioBruto;

    if (restante > 3856.94) {
        inss += (restante - 3856.94) * 0.14;
        restante = 3856.94;
    }
    if (restante > 2571.29) {
        inss += (restante - 2571.29) * 0.12;
        restante = 2571.29;
    }
    if (restante > 1320.00) {
        inss += (restante - 1320.00) * 0.09;
        restante = 1320.00;
    }
    inss += restante * 0.075;

    // IRPF
    const baseIR = salarioBruto - inss;
    let irpf = 0;

    if (baseIR <= 2112.00) {
        irpf = 0;
    } else if (baseIR <= 2826.65) {
        irpf = baseIR * 0.075 - 158.40;
    } else if (baseIR <= 3751.06) {
        irpf = baseIR * 0.15 - 370.40;
    } else if (baseIR <= 4664.68) {
        irpf = baseIR * 0.225 - 651.73;
    } else {
        irpf = baseIR * 0.275 - 884.96;
    }

    // Vale Transporte
    let vt = 0;
    if (valeTransporte === "S") {
        vt = salarioBruto * 0.06;
    }

    const salarioLiquido = salarioBruto - inss - irpf - vt - outrasDeducoes;

    document.getElementById("resultado").innerText =
        `CÁLCULO TRABALHISTA\n` +
        `Salário Bruto R$ ${salarioBruto.toFixed(2)}\n` +
        `Desconto INSS - R$ ${inss.toFixed(2)}\n` +
        `Desconto IRPF - R$ ${irpf.toFixed(2)}\n` +
        `Desconto Vale Transporte - R$ ${vt.toFixed(2)}\n` +
        `Outras Deduções - R$ ${outrasDeducoes.toFixed(2)}\n` +
        `Salário Líquido R$ ${salarioLiquido.toFixed(2)}`;
}
