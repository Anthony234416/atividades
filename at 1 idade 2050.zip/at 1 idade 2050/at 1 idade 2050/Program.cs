﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite o nome: ");
        string nome = Console.ReadLine();

        Console.Write("Digite o sexo (M/F): ");
        string sexo = Console.ReadLine();

        Console.Write("Digite o ano de nascimento: ");
        int anoNascimento = int.Parse(Console.ReadLine());

        Console.Write("Digite o ano corrente: ");
        int anoCorrente = int.Parse(Console.ReadLine());

        // Cálculo da idade atual e idade em 2050
        int idadeAtual = anoCorrente - anoNascimento;
        int idadeEm2050 = 2050 - anoNascimento;

        // Saída
        Console.WriteLine("\n--- INFORMAÇÕES ---");
        Console.WriteLine($"Nome: {nome}");
        Console.WriteLine($"Sexo: {sexo}");
        Console.WriteLine($"Idade atual: {idadeAtual} anos");
        Console.WriteLine($"Idade em 2050: {idadeEm2050} anos");
    }
}