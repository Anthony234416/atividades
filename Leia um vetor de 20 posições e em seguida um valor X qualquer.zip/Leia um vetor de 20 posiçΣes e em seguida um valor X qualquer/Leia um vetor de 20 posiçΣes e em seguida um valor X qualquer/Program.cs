﻿using System;

class Program
{
    static void Main()
    {
        int[] vetor = new int[20];
        bool encontrado = false;

        // Leitura do vetor
        Console.WriteLine("Digite 20 números:");
        for (int i = 0; i < 20; i++)
        {
            Console.Write($"Posição {i}: ");
            vetor[i] = int.Parse(Console.ReadLine());
        }

        // Leitura do valor a ser buscado
        Console.Write("\nDigite o valor a ser buscado (X): ");
        int x = int.Parse(Console.ReadLine());

        // Busca do valor X no vetor
        for (int i = 0; i < 20; i++)
        {
            if (vetor[i] == x)
            {
                Console.WriteLine($"\nValor {x} encontrado na posição {i}.");
                encontrado = true;
                break; // encerra a busca ao encontrar
            }
        }

        if (!encontrado)
        {
            Console.WriteLine($"\nValor {x} não foi encontrado no vetor.");
        }
    }
}
