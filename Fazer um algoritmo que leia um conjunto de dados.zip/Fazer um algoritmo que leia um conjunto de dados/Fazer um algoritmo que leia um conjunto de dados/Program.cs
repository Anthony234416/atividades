﻿using System;

class Program
{
    static void Main()
    {
        string nome, nomeMaisVelho = "";
        int idade, idadeMaisVelho = 0;
        int somaIdades = 0;
        int totalPessoas = 5;

        for (int i = 1; i <= totalPessoas; i++)
        {
            Console.WriteLine($"\nPessoa {i}:");

            Console.Write("Nome: ");
            nome = Console.ReadLine();

            Console.Write("Idade: ");
            idade = int.Parse(Console.ReadLine());

            // Acumula idade
            somaIdades += idade;

            // Verifica se é a maior idade
            if (idade > idadeMaisVelho)
            {
                idadeMaisVelho = idade;
                nomeMaisVelho = nome;
            }
        }

        // Calcula média
        double mediaIdades = (double)somaIdades / totalPessoas;

        // Saída
        Console.WriteLine("\n--- RESULTADOS ---");
        Console.WriteLine($"Idade média: {mediaIdades:F2} anos");
        Console.WriteLine($"Pessoa mais velha: {nomeMaisVelho} com {idadeMaisVelho} anos");
    }
}
