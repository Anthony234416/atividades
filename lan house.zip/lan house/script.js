function calcularValor() {
    const valor = Number(document.getElementById('valor').value);
    const tempo = Number(document.getElementById('tempo').value);
    
    const parcelas = Math.ceil(tempo / 15);
    const total = parcelas * valor;
  
    document.getElementById('saida').innerHTML = `Valor a Pagar R$: ${total.toFixed(2)}`;
  }
  