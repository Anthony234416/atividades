﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite o sexo (M ou F): ");
        string sexo = Console.ReadLine().ToUpper();

        Console.Write("Digite a altura em metros (ex: 1.75): ");
        double altura = double.Parse(Console.ReadLine());

        double pesoIdeal;

        // Cálculo do peso ideal conforme o sexo
        if (sexo == "M")
        {
            pesoIdeal = (72.7 * altura) - 58;
            Console.WriteLine($"\nPeso ideal para homem: {pesoIdeal:F2} kg");
        }
        else if (sexo == "F")
        {
            pesoIdeal = (62.1 * altura) - 44.7;
            Console.WriteLine($"\nPeso ideal para mulher: {pesoIdeal:F2} kg");
        }
        else
        {
            Console.WriteLine("\nSexo inválido. Digite apenas M ou F.");
        }
    }
}
