﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite o nome do aluno: ");
        string nome = Console.ReadLine();

        Console.Write("Digite a primeira nota: ");
        double nota1 = double.Parse(Console.ReadLine());

        Console.Write("Digite a segunda nota: ");
        double nota2 = double.Parse(Console.ReadLine());

        Console.Write("Digite a terceira nota: ");
        double nota3 = double.Parse(Console.ReadLine());

        Console.Write("Digite o número de faltas: ");
        int faltas = int.Parse(Console.ReadLine());

        // Cálculo da média
        double media = (nota1 + nota2 + nota3) / 3;

        // Verificação da situação
        string situacao;

        if (faltas > 27)
        {
            situacao = "Reprovado por Falta";
        }
        else if (media < 5.0)
        {
            situacao = "Reprovado por Média";
        }
        else
        {
            situacao = "Aprovado";
        }

        // Saída
        Console.WriteLine("\n--- RESULTADO FINAL ---");
        Console.WriteLine($"Aluno: {nome}");
        Console.WriteLine($"Média: {media:F2}");
        Console.WriteLine($"Faltas: {faltas}");
        Console.WriteLine($"Situação: {situacao}");
    }
}
