
function mensagemBotao1() {
  alert("Você clicou no 1º botão!");
}

function mensagemBotao2() {
alert("Você clicou no 2º botão!");
 
}


function mensagemBotao3() {
    alert("Você clicou no 3º botão!");
}