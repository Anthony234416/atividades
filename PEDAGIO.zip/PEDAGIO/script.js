const DISTANCIA_KM = 120;
const VALOR_PEDAGIO = 20.0;

const registros = [];
let inicioProcesso = null;
let finalProcesso = null;

document.getElementById('formRegistro').addEventListener('submit', function(event) {
  event.preventDefault();

  const placa = document.getElementById('placa').value.trim();
  const horaEntrada = document.getElementById('horaEntrada').value;
  const horaSaida = document.getElementById('horaSaida').value;

  const tempoHoras = calcularTempoEmHoras(horaEntrada, horaSaida);
  const velocidade = DISTANCIA_KM / tempoHoras;
  const desconto = calcularDesconto(velocidade);
  const valorPago = VALOR_PEDAGIO * (1 - desconto);

  const registro = {
    placa,
    horaEntrada,
    horaSaida,
    tempoHoras,
    velocidade,
    valorPago
  };

  registros.push(registro);

  if (!inicioProcesso || horaEntrada < inicioProcesso) inicioProcesso = horaEntrada;
  if (!finalProcesso || horaSaida > finalProcesso) finalProcesso = horaSaida;

  exibirTicket(registro);

  document.getElementById('formRegistro').reset();
});

document.getElementById('btnFecharCaixa').addEventListener('click', function() {
  gerarRelatorio();
});

function calcularTempoEmHoras(inicio, fim) {
  const [h1, m1] = inicio.split(':').map(Number);
  const [h2, m2] = fim.split(':').map(Number);
  const minutos = (h2 * 60 + m2) - (h1 * 60 + m1);
  return minutos / 60;
}

function calcularDesconto(velocidade) {
  if (velocidade <= 60) return 0.15;
  if (velocidade <= 100) return 0.10;
  return 0.0;
}

function exibirTicket(reg) {
  const div = document.getElementById('tickets');
  const ticket = document.createElement('div');
  ticket.className = 'bg-green-100 p-4 rounded shadow mb-2';
  ticket.innerHTML = `
    <p><strong>Placa:</strong> ${reg.placa}</p>
    <p><strong>Entrada:</strong> ${reg.horaEntrada}</p>
    <p><strong>Saída:</strong> ${reg.horaSaida}</p>
    <p><strong>Tempo (h):</strong> ${reg.tempoHoras.toFixed(2)}</p>
    <p><strong>Velocidade Média (km/h):</strong> ${reg.velocidade.toFixed(2)}</p>
    <p><strong>Valor Pago (R$):</strong> ${reg.valorPago.toFixed(2)}</p>
  `;
  div.appendChild(ticket);
}

function gerarRelatorio() {
  if (registros.length === 0) return;

  let menorVelocidade = Infinity;
  let maiorVelocidade = -Infinity;
  let somaVelocidades = 0;
  let totalValores = 0;

  registros.forEach(reg => {
    if (reg.velocidade < menorVelocidade) menorVelocidade = reg.velocidade;
    if (reg.velocidade > maiorVelocidade) maiorVelocidade = reg.velocidade;
    somaVelocidades += reg.velocidade;
    totalValores += reg.valorPago;
  });

  const mediaVelocidade = somaVelocidades / registros.length;

  const div = document.getElementById('relatorio');
  div.innerHTML = `
    <h2 class="text-2xl font-bold mb-2">Relatório do Turno</h2>
    <p><strong>Menor Velocidade:</strong> ${menorVelocidade.toFixed(2)} km/h</p>
    <p><strong>Maior Velocidade:</strong> ${maiorVelocidade.toFixed(2)} km/h</p>
    <p><strong>Média de Velocidades:</strong> ${mediaVelocidade.toFixed(2)} km/h</p>
    <p><strong>Total Cobrado:</strong> R$ ${totalValores.toFixed(2)}</p>
    <p><strong>Início do Processamento:</strong> ${inicioProcesso}</p>
    <p><strong>Fim do Processamento:</strong> ${finalProcesso}</p>
  `;
}
