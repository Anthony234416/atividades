
const display = document.querySelector('.display');


const buttons = document.querySelectorAll('button');

let currentInput = "";


buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.textContent;

    if (value === "AC") {
      currentInput = "";
      display.textContent = "0";
    } else if (value === "=") {
      try {
       
        const result = eval(currentInput.replace(/×/g, '*').replace(/÷/g, '/'));
        display.textContent = result;
        currentInput = result.toString(); // continua com o resultado
      } catch {
        display.textContent = "Erro";
        currentInput = "";
      }
    } else {
      // Adiciona ao input atual
      currentInput += value;
      display.textContent = currentInput;
    }
  });
});
