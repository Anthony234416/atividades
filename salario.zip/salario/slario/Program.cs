﻿using System;

class Program
{
    static void Main()
    {
        // Entrada de dados
        Console.Write("Digite o salário base do funcionário: R$ ");
        double salarioBase = double.Parse(Console.ReadLine());

        // Cálculo da gratificação (5%) e imposto (7%)
        double gratificacao = salarioBase * 0.05;
        double imposto = salarioBase * 0.07;

        // Cálculo do salário final
        double salarioReceber = salarioBase + gratificacao - imposto;

        // Saída
        Console.WriteLine("\n--- DETALHES DO SALÁRIO ---");
        Console.WriteLine($"Salário base: R$ {salarioBase:F2}");
        Console.WriteLine($"Gratificação (5%): R$ {gratificacao:F2}");
        Console.WriteLine($"Imposto (7%): R$ {imposto:F2}");
        Console.WriteLine($"Salário a receber: R$ {salarioReceber:F2}");
    }
}
